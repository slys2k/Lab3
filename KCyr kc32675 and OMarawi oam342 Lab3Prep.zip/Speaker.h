void PlayMusic(int* );
