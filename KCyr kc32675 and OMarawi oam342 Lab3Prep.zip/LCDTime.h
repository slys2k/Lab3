void DrawTimeLine(int time);
