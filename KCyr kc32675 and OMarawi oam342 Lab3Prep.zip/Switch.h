

void SwitchInit(void);
char SwitchPressed(char);

